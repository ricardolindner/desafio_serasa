/*Módulo para conectar no Banco de Dados local*/
const Sequelize = require("sequelize")

	// Conexão com o banco de dados MySQL
	const sequelize = new Sequelize("desafioserasa", "root", "BDsenha25522020*",{
	host: "localhost",
	dialect: "mysql"
	})

module.exports = {
	Sequelize: Sequelize,
	sequelize: sequelize
}