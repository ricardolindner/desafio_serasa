
/*Define constantes utilizadas para apurar a classificação da empresa conforme as notas e débitos*/
const INDICE_AUMENTO_NOTA = 1.02;
const INDICE_REDUCAO_NOTA = 0.96;

/*Instancia a Variável Classificação de Empresas, utilizada nas funções de cálculo*/
var classificacaoEmpresa = 0;


/*Funcção que calcula a classificação da empresa por nota fiscal*/
function processaNotasFiscais() {
	if (classificacaoEmpresa * INDICE_AUMENTO_NOTA > 100){
		return classificacaoEmpresa = 100;
	} else{
		return classificacaoEmpresa = Math.trunc(classificacaoEmpresa * INDICE_AUMENTO_NOTA);
	}
}

/*Função que calcula a classificação da empresa por débitos*/
/*Dado critério de arredondamento para cima o menor índice possível será 24%*/
function processaDebitos() {
	if (classificacaoEmpresa * INDICE_REDUCAO_NOTA < 1){
		return classificacaoEmpresa = 1;
	} else{
		return classificacaoEmpresa = Math.ceil(classificacaoEmpresa * INDICE_REDUCAO_NOTA);

	}
}

/*Função que calcula a classificação geral da empresa considerando o número de notas e número de débitos do período*/
function calculaClassificacao(ranking, notas, debitos) {
	classificacaoEmpresa = ranking;
	for(var i = 0; i < notas; i++){
		processaNotasFiscais();
	}

	for(var i = 0; i < debitos; i++){
		processaDebitos();
	}
	return classificacaoEmpresa;
}