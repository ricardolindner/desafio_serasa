/*Define as constantes com base nos framework */
const express = require("express");
const app = express();
const handlebars = require ("express-handlebars")
const bodyParser = require("body-parser")
const Empresa = require ("./empresa")

// Configurações das Engines
	// Template Engine
	app.engine("handlebars", handlebars ({defaultLayout: "main"}))
	app.set("view engine", "handlebars")

	//Body Parser
	app.use(bodyParser.urlencoded({extend: false}))
	app.use(bodyParser.json())
	

/*Define a Porta que o servidor vai rodar*/
app.listen(8081, function(){
	console.log("Servidor Rodando na url http://localhost:8081/")
});