/*Variável que busca informações no formulário em tela*/
var botaoCalcular = document.querySelector("#calcula-classificacao");

/*Função que concatena demais funções para gravar dados de formulário na tabela*/
botaoCalcular.addEventListener("click", function(event){
    event.preventDefault();

    var formulario = document.querySelector("#form-calcula");
    var empresa = obtemEmpresaDoFormulario(formulario);

    console.log(empresa);

    var erros = validaEmpresa(empresa);
    console.log(erros);
    if (erros.length > 0) {
        exibeMensagensDeErro(erros);
        return;
    }

    adicionaEmpresaNaTabela(empresa);

    formulario.reset();

    var mensagensErro = document.querySelector("#mensagens-erro");
    mensagensErro.innerHTML = "";
});

/*Função que grava dados de formulário na tabela*/
function adicionaEmpresaNaTabela(empresa){
    var empresaTr = montaTr(empresa);
    var tabela = document.querySelector("#tabela-empresas");
    tabela.appendChild(empresaTr);
}

/*Função que captura os dados do formulário*/
function obtemEmpresaDoFormulario(formulario){
    var empresa = {
        nome: formulario.empresa.value,
        ranking: formulario.ranking.value,
        notas: formulario.notas.value,
        debitos: formulario.debitos.value,
        rankingFinal: (calculaClassificacao(formulario.ranking.value, formulario.notas.value, formulario.debitos.value)+"%")
    }
    return empresa;
}

/*Função que monta Tr do HTML automaticamente*/
function montaTr(empresa){
    var empresaTr = document.createElement("tr");
    empresaTr.classList.add("empresa");

    empresaTr.appendChild(montaTD(empresa.nome, "info-nome"));
    empresaTr.appendChild(montaTD(empresa.ranking, "info-ranking"));
    empresaTr.appendChild(montaTD(empresa.notas, "info-notas"));
    empresaTr.appendChild(montaTD(empresa.debitos, "info-debitos"));
    empresaTr.appendChild(montaTD(empresa.rankingFinal, "info-rankingFinal"));  

    return empresaTr;
}

/*Função que monta Td do HTML automaticamente*/
function montaTD(dado, classe){
    var td = document.createElement("td");
    td.textContent = dado;
    td.classList.add(classe);

    return td;
}

/*Função que valida as informações do ranking preenchidas no teste unitário*/
function validaRankingInicial(ranking){
    if (ranking >= 1 && ranking <= 100){
        return true;
    }else{
        return false;
    }
}

/*Função que valida as informações de notas preenchidas no teste unitário*/
function validaNotas(notas){
    if (notas >= 0){
        return true;
    }else{
        return false;
    }
}

/*Função que valida as informações de débitos preenchidas no teste unitário*/
function validaDebitos(debitos){
    if (debitos >= 0){
        return true;
    }else{
        return false;
    }
}

/*Função que valida em conjunto as todas as informações necessárias o teste unitário*/
function validaEmpresa(empresa){
    
    /*Define a variável erros como um array vazio*/
    var erros = [];

    /*Se a validação do ranking da empresa resultar em falso registra mensagem de erro no array*/
    if(!validaRankingInicial(empresa.ranking)) 
        erros.push("O Ranking Inicial informado não é válido!");
    /*Se a validação das notas da empresa resultar em falso registra mensagem de erro no array*/
    if (!validaNotas(empresa.notas)) 
        erros.push("O número de Notas informado não é válido!")

    /*Se a validação dos débitos da empresa resultar em falso registra mensagem de erro no array*/
    if (!validaDebitos(empresa.debitos)) 
        erros.push("O número de Débitos informado não não é válido!")

    /*Verifica se o campo nome da empresa está em branco no formulário*/
    if( empresa.nome.length == 0){
        erros.push ("O nome da empresa não pode ficar em branco!");
    }

    /*Verifica se o campo ranking está em branco no formulário*/
    if( empresa.ranking.length == 0){
        erros.push ("O ranking inicial da empresa não pode ficar em branco!");
    }

    /*Verifica se o campo notas está em branco no formulário*/
    if( empresa.notas.length == 0){
        erros.push ("O número de notas no mês não pode ficar em branco!");
    }

    /*Verifica se o campo débitos está em branco no formulário*/
    if( empresa.debitos.length == 0){
        erros.push ("O número de débitos no mês não pode ficar em branco!");
    }

    return erros;
}

function exibeMensagensDeErro(erros){
    var ul = document.querySelector("#mensagens-erro");
    ul.innerHTML = "";

    erros.forEach(function(erro){
        var li = document.createElement("li");
        li.textContent = erro;
        ul.appendChild(li);
    });
}