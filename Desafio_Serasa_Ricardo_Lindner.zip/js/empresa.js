/*Módulo que utiliza o módulo de conexão com o BD para importar a tabela empresa*/

const db = require("./db")

const empresa = db.sequelize.define("empresa",{
	IDEmpresa:{
		type: db.Sequelize.INTEGER
	},
	Nome:{
		type: db.Sequelize.STRING
	},
	CNPJ:{
		type: db.Sequelize.INTEGER
	},
	ClassificacaoEmpresa:{
		type: db.Sequelize.INTEGER
	}
})

module.exports = empresa